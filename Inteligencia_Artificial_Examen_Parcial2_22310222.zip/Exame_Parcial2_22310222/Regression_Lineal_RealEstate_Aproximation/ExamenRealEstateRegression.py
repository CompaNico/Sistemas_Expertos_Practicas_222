# -*- coding: utf-8 -*-
"""
Created on Sat May 17 19:53:37 2025

@author: c23ag
"""
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

def Auto_plot (Data,Xname,Yname,Title,GraphName):
    plt.plot(Data, color='red')
    plt.xlabel(Xname)
    plt.ylabel(Yname)
    plt.title(Title)
    plt.grid(True)
    plt.savefig(GraphName)
    plt.show()
    
#===================Generar todas las posibles variables en la ecuacion, dado el dataset=========================================
#======Condiciones iniciales,dataset y Tasa de aprendizaje============
Data=pd.read_csv("Real estate valuation data set.csv")
Data=np.array(Data)
TasaDeAprendizaje=0.01
JCompleto=[]
GradienteCompleto=[]
ValoresReales=[]
ValoresEstimados=[]

#=====Conteo de variables con posibles coefientes W==============
VariablesEnUso=Data.shape
CantidadDeDatos=VariablesEnUso[0]
MitadDeDatos=int(np.round_(CantidadDeDatos/2))
VariablesEnUso=VariablesEnUso[1]

#======Declaracion de variables Independientes en uso x0w0+x1w1+x2w2+...zwn=y donde z=1=================
Ytrain=Data[:MitadDeDatos,VariablesEnUso-1]
Variablestrain=Data[:MitadDeDatos,:-1]
Ytest=Data[MitadDeDatos:,VariablesEnUso-1]
Variablestest=Data[MitadDeDatos:,:-1]

#======Declaracion de Coeficientes (W) contemplando un posible termino constante (Z)=======================
"""h(x)=x0w0+x1w1+x2w2+zw3 donde z=1"""
W=np.zeros([VariablesEnUso-1])

#=========Normalizacion de datos metodo Z-Score===================================================================================
Ytrain = (Ytrain - Ytrain.mean(axis=0)) / Ytrain.std(axis=0)
Variablestrain = (Variablestrain - Variablestrain.mean(axis=0)) / Variablestrain.std(axis=0)

#===============================Busqueda de valores de W======================================================================
ContadorDeEpocas=0
RangoDeMuestreo=100
Separacion=0
B=0
while B==0:
    yp = Variablestrain.dot(W)  # cálculo de Y-estimada con todo el dataset 
    error =  yp-Ytrain  # vector de errores (diferencia estimado-real)
    # Función de costo(J) (error cuadrático medio)
    J = (1 / (2 * CantidadDeDatos)) * np.sum(error ** 2)
    if ContadorDeEpocas == RangoDeMuestreo*Separacion:
        JCompleto.append(J)
            

    # Gradiente
    G = (1 / CantidadDeDatos) * Variablestrain.T.dot(error)
    if ContadorDeEpocas == RangoDeMuestreo*Separacion:    
        GradienteCompleto.append(np.max(G))
        Separacion=Separacion+1

    # Actualizar W
    W = W - TasaDeAprendizaje * G
    # Contamos la epoca
    ContadorDeEpocas=ContadorDeEpocas+1
    
    if np.abs(np.max(G))<=0.001:
        B=1
#=============Desnaturalizacion de Parametros W==========================================================
# Desnormalizar los coeficientes (excepto bias)
W=np.insert(W, 0, 0)
W_ready = np.zeros_like(W)
W_ready[1:] = W[1:] * (Ytrain.std(axis=0) / Variablestrain.std(axis=0))

# Desnormalizar el bias
W_ready[0] = Ytrain.mean(axis=0) - np.sum(W_ready[1:] * Variablestrain.mean(axis=0))
W_ready=W_ready[1:]

#===============Testeo de valores de W===========================================================================
yp = Variablestest.dot(W_ready)

# ===============================Mostrar resultados finales =============================================================

print("Parámetros finales (W):")
print(W_ready)
print("Total de Epocas para encontrar W:")
print(ContadorDeEpocas)
print("Las tablas de se escalan en epocas con un rango de muestreo de:")
print(RangoDeMuestreo)


# Graficar evolución del error y el vector gradiente ======================================================================
Auto_plot(JCompleto, "Epoca", "Error", "Error Respecto a epoca","RealEstate Error.png")
Auto_plot(GradienteCompleto, "Epoca", "ValorDeVectorG", "Gradiente Respecto a epoca","RealEstate Gradiente.png")

# ====================Graficar Las Yestimadas y YReal=====================================================================
plt.plot(Ytest, label='Target', marker='o')
plt.plot(yp, label='Result', marker='s')

plt.title("Valores Reales vs Valores estimados por regression")
plt.xlabel("Índice")
plt.ylabel("Valor")
plt.legend()
plt.grid(True)
plt.savefig("Valores (Real y Estimado) RealEstate.png")
plt.show()