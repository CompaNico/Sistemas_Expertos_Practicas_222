# -*- Codigo para aproximar ecuaciones lineales con terminos inde -*-
"""
Created on Sat May 17 16:15:41 2025

@author: c23ag
"""

import numpy as np
import matplotlib.pyplot as plt

def Auto_plot (Data,Xname,Yname,Title,GraphName):
    plt.plot(Data, color='red')
    plt.xlabel(Xname)
    plt.ylabel(Yname)
    plt.title(Title)
    plt.grid(True)
    plt.savefig(GraphName)
    plt.show()



#======Condiciones iniciales,dataset, vector de coeficientes originales, Tasa de aprendizaje============
Dataset=np.random.randint(1, 11, size=(10000, 4))  # Valores de x al azar para evaluar en la funcion 
VectorDeCoeficientes=np.array([4,2,3,4,3])
TasaDeAprendizaje=0.01
JCompleto=[]
JCercano0=[]
GradienteCompleto=[]
GradienteCercano0=[]

#======Declaracion de variables Independientes en uso x0w0+x1w1+x2w2+...zwn=y donde z=1=================
Z=np.ones_like(Dataset[:,0])
Dataset=np.insert(Dataset,(Dataset.shape[1]), Z,axis=1)
Y=Dataset.dot(VectorDeCoeficientes)

#=====Conteo de variables con posibles coefientes W==============
VariablesEnUso=Dataset.shape
CantidadDeDatos=VariablesEnUso[0]
VariablesEnUso=VariablesEnUso[1]

#======Declaracion de Coeficientes (W) contemplando un posible termino constante (Z)=======================
"""h(x)=x0w0+x1w1+x2w2+zw3 donde z=1"""
W=np.zeros([VariablesEnUso])

#Busqueda de valores de W======================================================================
ContadorDeEpocas=0
RangoDeMuestreo=100
Separacion=0
B=0
while B==0:
    yp = Dataset.dot(W)  # cálculo de Y-estimada con todo el dataset 
    error =  yp-Y  # vector de errores (diferencia estimado-real)

    # Función de costo(J) (error cuadrático medio)
    J = (1 / (2 * CantidadDeDatos)) * np.sum(error ** 2)
    if ContadorDeEpocas == RangoDeMuestreo*Separacion:
        if J <100 and J>-1:
            JCercano0.append(J)
        JCompleto.append(J)
            

    # Gradiente
    G = (1 / CantidadDeDatos) * Dataset.T.dot(error)
    if ContadorDeEpocas == RangoDeMuestreo*Separacion:    
        
        if np.max(G)<1 and np.max(G)>-50:
            GradienteCercano0.append(np.max(G))
        GradienteCompleto.append(np.max(G))
        Separacion=Separacion+1

    # Actualizar W
    W = W - TasaDeAprendizaje * G
    # Contamos la epoca
    ContadorDeEpocas=ContadorDeEpocas+1
    
    if np.abs(np.max(G))<=0.0002:
        B=1

# Mostrar resultados finales ================================================================================

print("Parámetros finales (W):")
print(W)
print("Parámetros Originales:")
print(VectorDeCoeficientes)
print("Total de Epocas para encontrar W:")
print(ContadorDeEpocas)
print("Las tablas de se escalan en epocas con un rango de muestreo de:")
print(RangoDeMuestreo)


# Graficar evolución del error y el vector gradiente ======================================================================
Auto_plot(JCercano0, "Epoca", "Error", "Error en detalle cercano a cero","ErrorCercanoACero.png")
Auto_plot(GradienteCercano0, "Epoca", "ValorDeVectorG", "Gradiente en detalle cercano a cero","GradienteCercano0.png")
Auto_plot(JCompleto, "Epoca", "Error", "Error Respecto a epoca","Error.png")
Auto_plot(GradienteCompleto, "Epoca", "ValorDeVectorG", "Gradiente Respecto a epoca","Gradiente.png")



