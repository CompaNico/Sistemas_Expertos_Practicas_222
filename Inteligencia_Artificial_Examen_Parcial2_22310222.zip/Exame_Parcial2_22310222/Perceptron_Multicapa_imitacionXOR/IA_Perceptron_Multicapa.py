# -*- Codigo para imitar el comprtamineto de una compuerta XOR -*-
"""
Created on Sat May 17 18:40:40 2025

@author: c23ag
"""

import numpy as np
import matplotlib.pyplot as plt

# Función de activación sigmoide y su derivada
def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def sigmoid_deriv(x):
    return x * (1 - x)

#=================================Condiciones Ininciales===============================================
# Datos de entrada
X = np.array([
    [0, 0],
    [0, 1],
    [1, 0],
    [1, 1]
])
# Salida deseada
Y = np.array([[0], [1], [1], [0]])
ErrorMax=[]
ErrorMin=[]
Epocas=[]
#===========Inicializamos Valores de W y neuronas=====================================================
# Semilla para retener los mismos numeros "Aleatorios"
np.random.seed(42)
# Inicialización de pesos aleatorios
n_input = 2
n_hidden = 2
n_output = 1

# W y Bias
W1 = np.random.uniform(-1, 1, (n_input, n_hidden))  
b1 = np.zeros((1, n_hidden))

W2 = np.random.uniform(-1, 1, (n_hidden, n_output))  
b2 = np.zeros((1, n_output))                        

#==================Parametros de aprendizaje=============================================================
TazaDeAprendizaje = 0.1
ContadorDeEpocas = 0
RangoDeMuestreo=10

#====================Busqueda de parametros W=============================================================
B=0
while B==0:
    # Propagacion hacia delante
    Z1 = np.dot(X, W1) + b1
    A1 = sigmoid(Z1)

    Z2 = np.dot(A1, W2) + b2
    A2 = sigmoid(Z2)

    # Retopropagacion
    error = Y - A2
    dZ2 = error * sigmoid_deriv(A2)
    dW2 = np.dot(A1.T, dZ2)
    db2 = np.sum(dZ2, axis=0, keepdims=True)

    dA1 = np.dot(dZ2, W2.T)
    dZ1 = dA1 * sigmoid_deriv(A1)
    dW1 = np.dot(X.T, dZ1)
    db1 = np.sum(dZ1, axis=0, keepdims=True)

    # Actualizacion de pesos
    W2 += TazaDeAprendizaje * dW2
    b2 += TazaDeAprendizaje * db2
    W1 += TazaDeAprendizaje * dW1
    b1 += TazaDeAprendizaje * db1
    # Contamos las epocas que lleva de aprendizaje
    ContadorDeEpocas=ContadorDeEpocas+1
    #Buscamos el error positivo de la propagacion hacia delante
    J=np.max(error)

    # Almacenamos el error con respecto al rando de muestreo
    if ContadorDeEpocas % RangoDeMuestreo == 0:
        ErrorMax.append(np.max(error))
        ErrorMin.append(np.min(error))
        Epocas.append(ContadorDeEpocas)
 #   Dejamos de evaluar para W cuando tenemos un error (J) de +- 0.05
    if J<=0.05:
         B=1
#================================== Resultados finales =========================================================
print("\nPredicciones finales:")
for i in range(4):
    x_input = X[i].reshape(1, -1)
    hidden = sigmoid(np.dot(x_input, W1) + b1)
    output = sigmoid(np.dot(hidden, W2) + b2)
    print("Entrada:", x_input)
    print("Predicción:", round(output[0][0], 4))
    print("-" * 30)
#Mostramos la cantidad de Epocas necesarias
print("Epocas necesarias para encontrar W")
print(ContadorDeEpocas)
    
#Graficamos los errores correspondinetes a cada propagacion
plt.plot(Epocas, ErrorMax, label='Max', color='blue')   
plt.plot(Epocas, ErrorMin, label='Min', color='red')      

plt.xlabel("Epocas")
plt.ylabel("Error")
plt.title("Comparación de Error minimo y maximo")

plt.legend()
plt.savefig("Error Minimo y Maximo.png")
plt.show()

