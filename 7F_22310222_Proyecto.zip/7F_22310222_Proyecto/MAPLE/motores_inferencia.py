def inferencia_materiales(dataset, user_answers):
    """
    Motor de inferencia para selección de materiales.
    dataset: diccionario con materiales y sus características (valores 1-10).
    user_answers: lista de valores del usuario (1-10).
    """

    resultados = []

    # 1. Calcular puntaje global con tolerancia ±1
    for material, datos in dataset.items():
        nombre_generico = datos[0]
        valores = [int(v) for v in datos[1:12] if v.isdigit()]  # tomar solo los 11 valores numéricos

        puntos = 0
        for i, val in enumerate(user_answers):
            if i < len(valores):
                if abs(valores[i] - val) <= 1:
                    puntos += 1

        resultados.append((material, nombre_generico, puntos))

    # Ordenar por puntaje descendente
    resultados.sort(key=lambda x: x[2], reverse=True)

    # 2. Detectar si las respuestas son homogéneas o heterogéneas
    rango = max(user_answers) - min(user_answers)
    homogeneo = rango <= 3  # si los valores están cercanos, se considera homogéneo

    # 3. Generar recomendaciones
    print("\n--- Material Selection Results ---")
    print(f"Most recommended material: {resultados[0][0]} ({resultados[0][1]}) with {resultados[0][2]} points")
    print(f"Runner up: {resultados[1][0]} ({resultados[1][1]}) with {resultados[1][2]} points")

    recomendaciones = {
        "most_recommended": {"material": resultados[0][0], "type": resultados[0][1], "points": resultados[0][2]},
        "runner_up": {"material": resultados[1][0], "type": resultados[1][1], "points": resultados[1][2]},
        "additional": []
    }

    if homogeneo:
        # Caso homogéneo → mostrar 3 adicionales
        print("\nAdditional recommendations (general):")
        for mat in resultados[2:5]:
            print(f"- {mat[0]} ({mat[1]}) with {mat[2]} points")
            recomendaciones["additional"].append({"material": mat[0], "type": mat[1], "points": mat[2]})
    else:
        # Caso heterogéneo → mostrar 2 basados en características prioritarias
        print("\nAdditional recommendations (specific to high values):")
        # Identificar las 3 características más altas
        top_indices = sorted(range(len(user_answers)), key=lambda i: user_answers[i], reverse=True)[:3]

        # Buscar materiales que mejor cumplen esas características
        for idx in top_indices[:2]:
            mejor = max(dataset.items(), key=lambda item: int(item[1][idx+1]) if item[1][idx+1].isdigit() else 0)
            print(f"- {mejor[0]} ({mejor[1][0]}) best for characteristic {idx+1}")
            recomendaciones["additional"].append({"material": mejor[0], "type": mejor[1][0], "characteristic": idx+1})
    
    return recomendaciones

def inferencia_procesos(materiales_compatibles, procesos_dataset, user_answers):
    """
    Motor de inferencia para selección de procesos de manufactura.
    materiales_compatibles: dict con materiales y lista de procesos compatibles.
    procesos_dataset: dict con procesos y sus características (valores 1-3).
    user_answers: lista con material elegido + valores numéricos (1-3).
    """

    # 1. Extraer material y respuestas
    material = user_answers[0]
    respuestas = user_answers[1:]  # solo los valores numéricos

    # 2. Obtener procesos compatibles
    if material not in materiales_compatibles:
        print(f"Material '{material}' no encontrado en dataset de compatibilidad.")
        return None

    # Los procesos vienen como string con lista, así que limpiamos
    procesos_compatibles = eval(materiales_compatibles[material][0])

    resultados = []

    # 3. Comparar valores exactos con dataset de procesos
    for proceso in procesos_compatibles:
        if proceso in procesos_dataset:
            valores = [int(v) for v in procesos_dataset[proceso] if v.isdigit()]
            puntos = 0
            for i, val in enumerate(respuestas):
                if i < len(valores) and valores[i] == val:
                    puntos += 1
            resultados.append((proceso, puntos))

    # 4. Ordenar por puntaje descendente
    resultados.sort(key=lambda x: x[1], reverse=True)

    # 5. Mostrar recomendaciones
    print("\n--- Manufacturing Process Selection Results ---")
    if resultados:
        print(f"Most recommended process: {resultados[0][0]} with {resultados[0][1]} points")
        if len(resultados) > 1:
            print(f"Runner up 1: {resultados[1][0]} with {resultados[1][1]} points")
        if len(resultados) > 2:
            print(f"Runner up 2: {resultados[2][0]} with {resultados[2][1]} points")
    else:
        print("No compatible processes found.")

    # 6. Guardar recomendaciones en diccionario
    recomendaciones = {
        "material": material,
        "most_recommended": {"process": resultados[0][0], "points": resultados[0][1]} if resultados else None,
        "runner_up": [
            {"process": resultados[i][0], "points": resultados[i][1]} for i in range(1, min(3, len(resultados)))
        ]
    }
    return recomendaciones

def motor_combinado(dataset_materiales, dataset_procesos, dataset_compatibilidad,
                    respuestas_material, respuestas_proceso):
    """
    Motor de inferencia combinado: selecciona materiales y procesos de manufactura.
    - dataset_materiales: dict con materiales y sus características (valores 1-10).
    - dataset_procesos: dict con procesos y sus características (valores 1-3).
    - dataset_compatibilidad: dict con materiales y lista de procesos compatibles.
    - respuestas_material: lista de valores del usuario para materiales (1-10).
    - respuestas_proceso: lista con material elegido + valores del usuario para procesos (1-3).
    """

    # ---------------------------
    # 1. Evaluación de materiales
    # ---------------------------
    resultados_materiales = []
    for material, datos in dataset_materiales.items():
        nombre_generico = datos[0]
        valores = [int(v) for v in datos[1:12] if v.isdigit()]
        puntos = 0
        for i, val in enumerate(respuestas_material):
            if i < len(valores) and abs(valores[i] - val) <= 1:
                puntos += 1
        resultados_materiales.append((material, nombre_generico, puntos))

    # Ordenar materiales por puntaje
    resultados_materiales.sort(key=lambda x: x[2], reverse=True)

    # Tomar los 4 más recomendados
    materiales_recomendados = resultados_materiales[:4]

    # ---------------------------
    # 2. Evaluación de procesos por material
    # ---------------------------
    recomendaciones_finales = {}

    for mat, nombre_gen, puntos_mat in materiales_recomendados:
        # Obtener procesos compatibles
        if nombre_gen in dataset_compatibilidad:
            procesos_compatibles = eval(dataset_compatibilidad[nombre_gen][0])
        else:
            procesos_compatibles = []

        resultados_procesos = []
        respuestas_proc = respuestas_proceso[1:]  # valores numéricos del usuario

        for proceso in procesos_compatibles:
            if proceso in dataset_procesos:
                valores_proc = [int(v) for v in dataset_procesos[proceso] if v.isdigit()]
                puntos_proc = 0
                for i, val in enumerate(respuestas_proc):
                    if i < len(valores_proc) and valores_proc[i] == val:
                        puntos_proc += 1
                resultados_procesos.append((proceso, puntos_proc))

        # Ordenar procesos por puntaje y tomar los 3 mejores
        resultados_procesos.sort(key=lambda x: x[1], reverse=True)
        procesos_recomendados = resultados_procesos[:3]

        # Guardar en diccionario final
        recomendaciones_finales[mat] = {
            "material_general": nombre_gen,
            "points": puntos_mat,
            "processes": [{"process": p[0], "points": p[1]} for p in procesos_recomendados]
        }

    # ---------------------------
    # 3. Mostrar resultados en terminal
    # ---------------------------
    print("\n=== Combined Material & Process Recommendations ===")
    for mat, info in recomendaciones_finales.items():
        print(f"\nMaterial: {mat} ({info['material_general']}) - {info['points']} points")
        print("Recommended processes:")
        for proc in info["processes"]:
            print(f" - {proc['process']} ({proc['points']} points)")
    return recomendaciones_finales
