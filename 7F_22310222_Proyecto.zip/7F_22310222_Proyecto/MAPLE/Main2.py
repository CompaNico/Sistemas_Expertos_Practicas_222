import csv
import os
import questionaires
from questionaires import manufacturing_questionnaire,material_questionnaire
from motores_inferencia import inferencia_materiales,inferencia_procesos, motor_combinado
from history import mostrar_historial,guardar_en_historial,navegador_historial

def clear_terminal():
    # En Windows el comando es 'cls', en Linux/Mac es 'clear'
    os.system('cls' if os.name == 'nt' else 'clear')

def cargar_csv_como_diccionario(filename):
    diccionario = {}
    with open(filename, newline='', encoding='utf-8') as f:
        reader = csv.reader(f)
        headers = next(reader)  # Headers
        nombre_lista = headers[0]  # List name = first column

        for row in reader:
            if not row or not row[0]:
                continue  # Skip empty rows
            clave = row[0]  # First column = key
            valores = row[1:]  # Rest of columns = values
            diccionario[clave] = valores

    return nombre_lista, diccionario



# Load the three datasets
nombre1, manufacturing_dict = cargar_csv_como_diccionario("Manufacturing_Processes_Dataset.csv")
nombre2, compatibility_dict = cargar_csv_como_diccionario("material_process_compatibility.csv")
nombre3, materials_dict = cargar_csv_como_diccionario("Materials_Dataset.csv")

#======================Main Menu===========================================================================
def main():
    clear_terminal()
    while True:
        print("\n=== M.A.P.L.E Expert System ===")
        print("1. New project assessment")
        print("2. Project history\n")
        print("3.About M.A.P.L.E.")
        print("4. Exit")
        
        choice = input("Select an option: ")
        clear_terminal()

        if choice == "1":
            new_project_menu()
        elif choice == "2":
            mostrar_historial()
            navegador_historial()
        elif choice == "3":
            print("""M.A.P.L.E is an expert system created to help engineers, hobbyists, makers… 
anyone that's looking to build any sort of mechanical project by offering baseline 
materials for your parts and how you should make them. By asking you simple questions that 
have to do with design, material specification, geometry, and other characteristics, 
M.A.P.L.E. is able to determine specific alloys or series of materials that suit your needs. 
As well as what manufacturing process best suits your part, priorities, and material selection.""")
            input("\nPress enter to return to main menu")
        elif choice == "4":
            print("Exiting system...")
            break
        else:
            print("Invalid option, please try again.")

#==================================New Project Menu========================================================
def new_project_menu():
    while True:
        print("\n--- New Project Assessment ---")
        print("1. Full assessment (MFG + MT)")
        print("2. Manufacturing process (MFG)")
        print("3. Material selection (MT)")
        print("4. Back to main menu")

        choice = input("Select an option: ")
        clear_terminal()
#---------------------------------Full assesment---------------------------------------------------------------------
        if choice == "1":
            name=input("\n\nWhat is the name of your project?:")
            Answers_MT=material_questionnaire()
            Answers_MFG=manufacturing_questionnaire()
            recomendation_full=motor_combinado(materials_dict,manufacturing_dict,compatibility_dict,Answers_MT,Answers_MFG)
            guardar_en_historial(name,recomendation_full)
            input("Press Enter to continue...")
            clear_terminal()
 #-------------------------------Manufacturing Process (MFG)------------------------------------------------------------           
        elif choice == "2":
            name=input("\n\nWhat is the name of your project?:")
            Answers_MFG=[]
            possible_materials = [
            "Aluminium", "Cast Aluminium", "Brass", "Cast Brass", "Carbon Fiber",
            "Fiberglass", "GRN", "Cast Iron", "Magnisium", "Cast Magnisium",
            "Polymer", "Rubber", "Stainless steel", "Cast Stainless steel",
            "Steel", "Cast Steel", "Titanium", "Tungsten Carbide", "Zinc" ]

            while True:
                #Primero pedimos el material que se va a utilizar
                print("What material will you use?")
                print(possible_materials)
                ans=input("Write down your material:")
                if ans in possible_materials:
                    Answers_MFG.append(ans)  # Guardamos como string
                    clear_terminal()
                    break
                else:
                        clear_terminal()
                        print("Invalid input, please choose from the list.")

            #Cuestionario Normal
            Answers_temp=manufacturing_questionnaire()
            Answers_MFG.extend(Answers_temp)
            recomendation_MFG=inferencia_procesos(compatibility_dict,manufacturing_dict,Answers_MFG)
            guardar_en_historial(name,recomendation_MFG)
            input("Press Enter to continue...")
            clear_terminal()

#-------------------------------Material Selection (MT)----------------------------------------------------------------
        elif choice == "3":
            name=input("\n\nWhat is the name of your project?:")
            Answers_MT=material_questionnaire()
            print("\n--- Questionnaire Completed ---")
            recomendation_MT=inferencia_materiales(materials_dict,Answers_MT)
            guardar_en_historial(name,recomendation_MT)
            input("Press Enter to continue...")
            clear_terminal()
#--------------------------EXIT---------------------------------------------------------------------------------------------------------
        elif choice == "4":
            break
        else:
            print("Invalid option, please try again.")
#=======================Sub-Processes============================================================================


if __name__ == "__main__":
    main()
