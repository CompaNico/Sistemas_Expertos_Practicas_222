import os
def clear_terminal():
    # En Windows el comando es 'cls', en Linux/Mac es 'clear'
    os.system('cls' if os.name == 'nt' else 'clear')

def manufacturing_questionnaire():
    questions = [
        ("Does your part require precision?", [
            "1. Dimensional tolerance of 0.5 mm",
            "2. Dimensional tolerance of 0.1 mm",
            "3. Dimensional tolerance of 0.01 mm"
        ]),
        ("Does your part have complex curvatures?", [
            "1. None or little curvatures",
            "2. Some curvatures",
            "3. Lots of curvatures"
        ]),
        ("Does your part contain complex and thin surfaces?", [
            "1. None or little",
            "2. Some thin surfaces",
            "3. Mostly thin surfaces"
        ]),
        ("Is your part made-up of angular square geometries?", [
            "1. None or little",
            "2. Some square geometries",
            "3. Mostly square geometries"
        ]),
        ("Is your part made-up of angular circular geometry?", [
            "1. None or little",
            "2. Some radiuses",
            "3. Mostly radiuses"
        ]),
        ("What is the overall size of your part?", [
            "1. 12 cm in any direction or less",
            "2. 50 cm in any direction",
            "3. More than 100 cm in any direction"
        ]),
        ("How much could the part weigh?", [
            "1. Less than 0.5kg",
            "2. Between 0.5 and 20 kg",
            "3. More than 40kg"
        ]),
        ("Could your part be made with relatively thin sheet/plates or a block of material?", [
            "1. Sheet",
            "2. Block"
        ]),
        ("How long could you wait for the finished part?", [
            "1. I need to receive the part as soon as possible",
            "2. I can wait two months",
            "3. I can wait four months"
        ]),
        ("How many parts do you plan on making?", [
            "1. From 1 to 3 parts",
            "2. From 3 to 15 parts",
            "3. More than 100 parts"
        ]),
        ("What are you looking for in terms of cost?", [
            "1. Low cost",
            "2. Im willing to pay a good price for my parts",
            "3. I need the best parts I can get, no matter the cost"
        ])
    ]

    answers = []

    print("\n--- Manufacturing Process Questionnaire ---")

    for q, options in questions:
        print(f"\n{q}")
        for opt in options:
            print(opt)

        while True:
            try:
                ans = int(input("Select an option (number): "))
                if 1 <= ans <= len(options):
                    answers.append(ans)
                    break
                else:
                    print("Invalid option, please try again.")
            except ValueError:
                print("Invalid input, please enter a number.")
        clear_terminal()
    return answers


def material_questionnaire():
    questions = [
        ("How temperature resistant does your part need to be?", 
         "1. Low temperature resistance\n10. Extreme high temperature resistance"),
        
        ("Will your part be under constant friction and wear?", 
         "1. Low wear resistance\n10. Very high wear resistance"),
        
        ("Does your part need to be corrosion resistant?", 
         "1. Low corrosion resistance\n10. Very high corrosion resistance"),
        
        ("Is your part made to dissipate heat or is overheating a concern?", 
         "1. Low thermal dissipation\n10. High thermal dissipation"),
        
        ("Do you need for your part to conduct electricity?", 
         "1. Low conductivity\n10. High conductivity"),
        
        ("Do you need chemical resistance for your part?", 
         "1. Low chemical resistance\n10. High chemical resistance"),
        
        ("How heavy can your part be?", 
         "1. Very heavy\n10. Lightweight"),

         ("Does your part need to withstand impacts?", 
         "1. Low impact resistance\n10. Very high impact resistance"),
        
        ("Do you need your part to have resistance to deforming under constant stress?", 
         "1. High deformation\n10. Least deformation possible"),
        
        ("Does your part need to have elastic properties?", 
         "1. Low elasticity\n10. Very high elasticity"),
        
        ("What price range are you looking for?", 
         "1. Very low cost\n10. High cost")
    ]

    answers = []

    print("\n--- Material Selection Questionnaire ---")

    for q, scale in questions:
        print(f"\n{q}")
        print(scale)

        while True:
            try:
                ans = int(input("Select a value (1-10): "))
                if 1 <= ans <= 10:
                    answers.append(ans)
                    break
                else:
                    print("Invalid option, please enter a number between 1 and 10.")
            except ValueError:
                print("Invalid input, please enter a number.")
        
        clear_terminal()  # limpia la terminal entre preguntas

    return answers