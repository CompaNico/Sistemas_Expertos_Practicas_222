import json
import os
from datetime import datetime

HISTORIAL_FILE = "historial.json"

def clear_terminal():
    # On Windows the command is 'cls', on Linux/Mac it's 'clear'
    os.system('cls' if os.name == 'nt' else 'clear')

def guardar_en_historial(project_name, recommendation):
    new_entry = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "project_name": project_name,
        "recommendation": recommendation
    }

    # Load existing history
    try:
        with open(HISTORIAL_FILE, "r", encoding="utf-8") as f:
            history = json.load(f)
    except FileNotFoundError:
        history = []

    # Add new entry
    history.append(new_entry)

    # Save updated history
    with open(HISTORIAL_FILE, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=4, ensure_ascii=False)

    print("\nRecommendation saved to history.")


def mostrar_historial():
    try:
        with open(HISTORIAL_FILE, "r", encoding="utf-8") as f:
            history = json.load(f)
    except FileNotFoundError:
        print("\nNo history exists yet. Save a recommendation first.")
        return
    except json.JSONDecodeError:
        print("\nThe history file is empty or corrupted.")
        return

    if not history:
        print("\nThe history is empty.")
        return

    print("\n=== Recommendation History ===")
    for entry in history:
        print("\n========================================================")
        print(f"Date: {entry['timestamp']}")
        print(f"Project name: {entry.get('project_name', '(unspecified)')}")

        recommendation = entry["recommendation"]

        # Case 1: Material engine (only materials)
        if "most_recommended" in recommendation and "material" in recommendation["most_recommended"]:
            print("\nMaterial Recommendation:")
            mr = recommendation["most_recommended"]
            print(f" - Most recommended: {mr['material']} ({mr['type']}) with {mr['points']} points")

            if "runner_up" in recommendation and recommendation["runner_up"]:
                ru = recommendation["runner_up"]
                if isinstance(ru, dict):
                    print(f" - Runner up: {ru['material']} ({ru['type']}) with {ru['points']} points")
                elif isinstance(ru, list):
                    for i, mat in enumerate(ru, start=1):
                        print(f" - Runner up {i}: {mat['material']} ({mat['type']}) with {mat['points']} points")

            if "additional" in recommendation:
                print(" - Additional:")
                for mat in recommendation["additional"]:
                    print(f"   * {mat['material']} ({mat['type']}) with {mat['points']} points")

        # Case 2: Process engine (only processes)
        elif "material" in recommendation and "most_recommended" in recommendation:
            print(f"\nProcess Recommendation for material: {recommendation['material']}")
            mr = recommendation["most_recommended"]
            print(f" - Most recommended: {mr['process']} with {mr['points']} points")

            if "runner_up" in recommendation:
                for i, proc in enumerate(recommendation["runner_up"], start=1):
                    print(f" - Runner up {i}: {proc['process']} with {proc['points']} points")

        # Case 3: Combined engine (materials + processes)
        elif isinstance(recommendation, dict) and all(isinstance(v, dict) for v in recommendation.values()):
            print("\nCombined Recommendation (Materials + Processes):")
            for mat, info in recommendation.items():
                print(f"\nAlloy or series: {mat}")
                print(f"General material name: {info['material_general']}")
                print("Recommended processes:")
                for proc in info["processes"]:
                    print(f" - {proc['process']} ({proc['points']} points)")

        else:
            print("\nRecommendation (unknown format):")
            print(recommendation)


def mostrar_proyecto(entry):
    clear_terminal()
    print("\n=================")
    print(f"Date: {entry['timestamp']}")
    print(f"Project name: {entry.get('project_name', '(unspecified)')}")

    recommendation = entry["recommendation"]

    # Case: materials
    if "most_recommended" in recommendation and "material" in recommendation["most_recommended"]:
        print("\nMaterial Recommendation:")
        mr = recommendation["most_recommended"]
        print(f" - Most recommended: {mr['material']} ({mr['type']}) with {mr['points']} points")

        if "runner_up" in recommendation and recommendation["runner_up"]:
            ru = recommendation["runner_up"]
            if isinstance(ru, dict):
                print(f" - Runner up: {ru['material']} ({ru['type']}) with {ru['points']} points")
            elif isinstance(ru, list):
                for i, mat in enumerate(ru, start=1):
                    print(f" - Runner up {i}: {mat['material']} ({mat['type']}) with {mat['points']} points")

        if "additional" in recommendation:
            print(" - Additional:")
            for mat in recommendation["additional"]:
                print(f"   * {mat['material']} ({mat['type']}) with {mat['points']} points")

    # Case: processes
    elif "material" in recommendation and "most_recommended" in recommendation:
        print(f"\nProcess Recommendation for material: {recommendation['material']}")
        mr = recommendation["most_recommended"]
        print(f" - Most recommended: {mr['process']} with {mr['points']} points")

        if "runner_up" in recommendation:
            for i, proc in enumerate(recommendation["runner_up"], start=1):
                print(f" - Runner up {i}: {proc['process']} with {proc['points']} points")

    # Case: combined
    elif isinstance(recommendation, dict) and all(isinstance(v, dict) for v in recommendation.values()):
        print("\nCombined Recommendation (Materials + Processes):")
        for mat, info in recommendation.items():
            print(f"\nAlloy or series: {mat}")
            print(f"General material name: {info['material_general']}")
            print("Recommended processes:")
            for proc in info["processes"]:
                print(f" - {proc['process']} ({proc['points']} points)")

    else:
        print("\nRecommendation (unknown format):")
        print(recommendation)


def navegador_historial():
    """History Navigator"""
    try:
        with open(HISTORIAL_FILE, "r", encoding="utf-8") as f:
            history = json.load(f)
    except FileNotFoundError:
        print("\nNo history exists yet.")
        return
    except json.JSONDecodeError:
        print("\nThe history file is empty or corrupted.")
        return

    while True:
        print("\n=== History Navigator ===")
        print("1. Search project")
        print("2. Exit")
        option = input("Select an option (1-2): ").strip()
        clear_terminal()
        if option == "2":
            print("\nExiting history navigator.")
            break

        elif option == "1":
            criteria = input("\nEnter project name or date (YYYY-MM-DD HH:MM:SS): ").strip()

            # Search by name or date
            found = None
            for entry in history:
                if entry.get("project_name", "").lower() == criteria.lower() or entry["timestamp"] == criteria:
                    found = entry
                    break

            if found:
                mostrar_proyecto(found)
                input("\nPress Enter to return to full history...")
                mostrar_historial()
            else:
                print("\nNo project exists with that name or date.")

        else:
            print("\nInvalid option. Try again.")
